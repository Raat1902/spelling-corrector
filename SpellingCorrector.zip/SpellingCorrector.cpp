#include <iostream>
#include <vector>
#include <string>
#include <limits>
#include <algorithm>
#include <cctype>

using namespace std;

// Convert string to lowercase
string toLower(const string& s) {
    string res = s;
    for (char& c : res) c = tolower(c);
    return res;
}

// Levenshtein Distance
int editDistance(const string& a, const string& b) {
    int m = a.size(), n = b.size();
    vector<vector<int>> dp(m + 1, vector<int>(n + 1));

    for (int i = 0; i <= m; ++i) dp[i][0] = i;
    for (int j = 0; j <= n; ++j) dp[0][j] = j;

    for (int i = 1; i <= m; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (a[i - 1] == b[j - 1]) dp[i][j] = dp[i - 1][j - 1];
            else dp[i][j] = 1 + min({ dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1] });
        }
    }

    return dp[m][n];
}

// Get best match regardless of threshold
pair<string, int> getClosestWord(const string& input, const vector<string>& dictionary) {
    string inputLower = toLower(input);
    string bestMatch;
    int minDistance = numeric_limits<int>::max();

    for (const string& word : dictionary) {
        string wordLower = toLower(word);
        if (wordLower == inputLower) return {"", 0}; // word is correct

        int dist = editDistance(inputLower, wordLower);
        if (dist < minDistance) {
            minDistance = dist;
            bestMatch = word;
        }
    }

    return {bestMatch, minDistance};
}

int main() {
    vector<string> dictionary = {
        "hello", "world", "computer", "science", "program", "language", "keyboard", "screen", "the", "hi"
    };

    string input;
    cout << "Enter a word to spell-check: ";
    cin >> input;

    auto result = getClosestWord(input, dictionary);

    if (result.first == "") {
        cout << "Word is correct.\n";
    } else {
        cout << "Did you mean: " << result.first << "? (distance " << result.second << ")\n";
    }

    return 0;
}